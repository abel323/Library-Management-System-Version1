﻿Public Class frmIssueBook
    Dim cmd As New OleDb.OleDbCommand
    Dim sql As String
    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmAdminDashBoard.Show()
        Me.Dispose()
    End Sub

    Private Sub DisplayBooks()
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "SELECT * FROM Books"
                cmd.Connection = connection()
                cmd.CommandText = sql
                DA.SelectCommand = cmd
                DA.Fill(DT)
                dgvBook.DataSource = DT
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub
    Private Sub frmIssueBook_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DisplayBooks()
        Dim DR As OleDb.OleDbDataReader
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "SELECT ID FROM Student"
                cmd.Connection = connection()
                cmd.CommandText = sql
                DR = cmd.ExecuteReader
                While DR.Read
                    txtStudentID.Items.Add(CStr(DR("ID")))
                End While
                DR.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim searchBy As String = cboSearch.Text
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                Select Case searchBy
                    Case "ISBN"
                        sql = "SELECT * FROM Books WHERE ISBN='" & txtSearch.Text & "'"
                        cmd.Connection = connection()
                        cmd.CommandText = sql
                        DA.SelectCommand = cmd
                        DA.Fill(DT)
                        dgvBook.DataSource = DT
                    Case "Title"
                        sql = "SELECT * FROM Books WHERE Title LIKE '%" & txtSearch.Text & "%'"
                        cmd.Connection = connection()
                        cmd.CommandText = sql
                        DA.SelectCommand = cmd
                        DA.Fill(DT)
                        dgvBook.DataSource = DT
                    Case "Author"
                        sql = "SELECT * FROM Books WHERE Author LIKE '%" & txtSearch.Text & "%'"
                        cmd.Connection = connection()
                        cmd.CommandText = sql
                        DA.SelectCommand = cmd
                        DA.Fill(DT)
                        dgvBook.DataSource = DT
                End Select
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub

    Private Sub btnIssue_Click(sender As Object, e As EventArgs) Handles btnIssue.Click
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "INSERT INTO Borrow(ISBN,Student_ID,Borrow_Date,Expected_Due_Date)" &
                    "VALUES('" & txtISBN.Text & "'," & CInt(txtStudentID.Text) & ",'" & txtIssueDate.Text & "','" & txtReturnDate.Text & "')"
                cmd.Connection = connection()
                cmd.CommandText = sql
                If cmd.ExecuteNonQuery > 0 Then
                    MsgBox("Book Issued Successfully!")
                    sql = "UPDATE Books SET Quantity=Quantity-" & 1 & " WHERE ISBN='" & txtISBN.Text & "'"
                    cmd.CommandText = sql
                    If cmd.ExecuteNonQuery > 0 Then
                        MsgBox("Books Database Updated")
                        sql = "SELECT * FROM Books WHERE ISBN='" & txtISBN.Text & "'"
                        cmd.CommandText = sql
                        DA.SelectCommand = cmd
                        DA.Fill(DT)
                        dgvBook.DataSource = DT
                    Else
                        MsgBox("Could Not Update Books Database", vbCritical)
                    End If
                Else
                    MsgBox("Could Not Issue Book")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        txtSearch.Clear()
        txtISBN.Clear()
        txtStudentID.ResetText()
        txtIssueDate.ResetText()
        txtReturnDate.ResetText()
    End Sub
End Class