﻿Public Class frmBooks
    Dim cmd As New OleDb.OleDbCommand
    Dim sql As String
    Private Sub PublisherList()
        Dim DR As OleDb.OleDbDataReader
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "SELECT Publisher_Name FROM Publisher"
                cmd.Connection = connection()
                cmd.CommandText = sql
                DR = cmd.ExecuteReader
                While DR.Read
                    cboPublisher.Items.Add(CStr(DR("Publisher_Name")))
                End While
                DR.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub
    Private Sub frmBooks_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PublisherList()
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            AccessConnection.connection().Open()
            If AccessConnection.connection().State = ConnectionState.Open Then
                sql = "SELECT * FROM Books"
                cmd.Connection = AccessConnection.connection()
                cmd.CommandText = sql
                DA.SelectCommand = cmd
                DA.Fill(DT)
                dgvBooks.DataSource = DT
            Else
                MsgBox("Database connection error!", vbCritical)
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            AccessConnection.connection().Close()
        End Try
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmAdminDashBoard.Show()
        Me.Dispose()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            AccessConnection.connection().Open()
            If AccessConnection.connection().State = ConnectionState.Open Then
                sql = "INSERT INTO Books VALUES('" & txtISBN.Text & "','" & txtTitle.Text &
                    "','" & txtAuthor.Text & "'," & CDbl(txtPrice.Text) & "," & CInt(txtQuantity.Text) & CInt(cboPublisher.ValueMember.ToString) & ")"
                cmd.Connection = AccessConnection.connection()
                cmd.CommandText = sql
                If cmd.ExecuteNonQuery > 0 Then
                    MsgBox("Book Added Successfully!", vbInformation)
                    sql = "SELECT * FROM Books"
                    cmd.CommandText = sql
                    DA.SelectCommand = cmd
                    DA.Fill(DT)
                    dgvBooks.DataSource = DT
                Else
                    MsgBox("Could not add book!", vbCritical)
                End If
            Else
                MsgBox("Could not connect with database!", vbCritical)
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            AccessConnection.connection().Close()
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "DELETE FROM Books WHERE ISBN='" & txtISBN.Text & "'"
                cmd.Connection = connection()
                cmd.CommandText = sql
                If cmd.ExecuteNonQuery > 0 Then
                    MsgBox("Book Data Deleted Successfully!", vbInformation)
                    sql = "SELECT * FROM Books"
                    cmd.CommandText = sql
                    DA.SelectCommand = cmd
                    DA.Fill(DT)
                    dgvBooks.DataSource = DT
                Else
                    MsgBox("Could Not Delete Books Data", vbInformation)
                End If
            Else
                MsgBox("Unable to connect with database", vbCritical)
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "UPDATE Books SET Title='" & txtTitle.Text & "', Author='" & txtAuthor.Text & "', Price=" & CDbl(txtPrice.Text) & ", Quantity=" & CInt(txtQuantity.Text) &
                 " WHERE ISBN='" & txtISBN.Text & "'"
                cmd.Connection = connection()
                cmd.CommandText = sql
                If cmd.ExecuteNonQuery > 0 Then
                    MsgBox("Book Data Updated Successfully!", vbInformation)
                    sql = "SELECT * FROM Books"
                    cmd.CommandText = sql
                    DA.SelectCommand = cmd
                    DA.Fill(DT)
                    dgvBooks.DataSource = DT
                Else
                    MsgBox("Could  Not Update Books Database", vbCritical)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub

    Private Sub dgvBooks_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvBooks.CellContentClick
        txtISBN.Text = dgvBooks.Item(0, dgvBooks.CurrentRow.Index).Value
        txtTitle.Text = dgvBooks.Item(1, dgvBooks.CurrentRow.Index).Value
        txtAuthor.Text = dgvBooks.Item(2, dgvBooks.CurrentRow.Index).Value
        txtPrice.Text = CStr(dgvBooks.Item(3, dgvBooks.CurrentRow.Index).Value)
        txtQuantity.Text = CStr(dgvBooks.Item(4, dgvBooks.CurrentRow.Index).Value)
    End Sub
End Class