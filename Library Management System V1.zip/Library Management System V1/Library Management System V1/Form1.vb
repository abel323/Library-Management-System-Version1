﻿Public Class Form1
    Dim cmd As New OleDb.OleDbCommand
    Dim sql As String
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        txtUserName.Clear()
        txtPassword.Clear()
        cboUserType.ResetText()
        txtUserName.Select()
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        frmUserRegister.ShowDialog()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim DR As OleDb.OleDbDataReader
        Try
            AccessConnection.connection().Open()
            If AccessConnection.connection().State = ConnectionState.Open Then
                sql = "SELECT User_Name,User_Type,UPassword FROM tblUser WHERE User_Name='" & txtUserName.Text & "' AND User_Type='" & cboUserType.Text & "' AND UPassword='" & txtPassword.Text & "'"
                cmd.Connection = AccessConnection.connection()
                cmd.CommandText = sql
                DR = cmd.ExecuteReader
                If DR.HasRows = 0 Then
                    DR.Close()
                    MsgBox("Error: Pleace Check Your User Name, Role And Password! Your Accont Does Not Exist", vbCritical)
                Else
                    DR.Close()
                    connection().Close()
                    MsgBox("Logged In Successfully!")
                    cboUserType.ResetText()
                    txtUserName.Clear()
                    txtPassword.Clear()
                    frmAdminDashBoard.Show()
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub
End Class
