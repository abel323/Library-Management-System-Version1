﻿Public Class frmStudent
    Dim cmd As New OleDb.OleDbCommand
    Dim sql As String
    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmAdminDashBoard.Show()
        Me.Dispose()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim DT As New DataTable
        Dim DA As New OleDb.OleDbDataAdapter
        Dim Gender As String = ""
        If radMale.Checked Then
            Gender = "Male"
        ElseIf radFemale.Checked Then
            Gender = "Female"
        Else
            MsgBox("Please Select Gender", vbCritical)
        End If
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "INSERT INTO Student (First_Name, Last_Name, Middle_Name,Gender,Date_Of_Birth,Phone,Address) VALUES('" & txtFirstName.Text &
                    "','" & txtLastName.Text & "','" & txtMiddleName.Text & "','" & Gender & "','" & txtDOB.Text & "','" & txtPhone.Text & "','" & txtAddress.Text & "')"
                cmd.Connection = connection()
                cmd.CommandText = sql
                If cmd.ExecuteNonQuery > 0 Then
                    MsgBox("Student Added Successfully!", vbInformation)
                    sql = "SELECT * FROM Student"
                    cmd.CommandText = sql
                    DA.SelectCommand = cmd
                    DA.Fill(DT)
                    DataGridView1.DataSource = DT
                Else
                    MsgBox("Could not add student to the system!", vbCritical)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub

    Private Sub frmStudent_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtID.Visible = False
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "SELECT * FROM Student"
                cmd.Connection = connection()
                cmd.CommandText = sql
                DA.SelectCommand = cmd
                DA.Fill(DT)
                DataGridView1.DataSource = DT
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "DELETE FROM Student WHERE ID=" & CInt(txtID.Text)
                cmd.Connection = connection()
                cmd.CommandText = sql
                If cmd.ExecuteNonQuery > 0 Then
                    MsgBox("Student Data Deleted Successfully From The System!", vbInformation)
                    sql = "SELECT * FROM Student"
                    cmd.CommandText = sql
                    DA.SelectCommand = cmd
                    DA.Fill(DT)
                    DataGridView1.DataSource = DT
                Else
                    MsgBox("Could Not Delete Student Data!", vbCritical)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        txtID.Text = DataGridView1.Item(0, DataGridView1.CurrentRow.Index).Value
        txtFirstName.Text = DataGridView1.Item(1, DataGridView1.CurrentRow.Index).Value
        txtLastName.Text = DataGridView1.Item(2, DataGridView1.CurrentRow.Index).Value
        txtMiddleName.Text = DataGridView1.Item(3, DataGridView1.CurrentRow.Index).Value
        txtDOB.Text = DataGridView1.Item(5, DataGridView1.CurrentRow.Index).Value
        txtPhone.Text = DataGridView1.Item(6, DataGridView1.CurrentRow.Index).Value
        txtAddress.Text = DataGridView1.Item(7, DataGridView1.CurrentRow.Index).Value
    End Sub
End Class