﻿Module AccessConnection
    Dim conn As New OleDb.OleDbConnection("Provider=Microsoft.Ace.OleDb.12.0; Data source=D:/Access Databases/BooksDb.accdb")
    'Define connection function
    Function connection() As OleDb.OleDbConnection
        Return conn
    End Function

End Module
