﻿Public Class frmAdminDashBoard
    Dim cmd As New OleDb.OleDbCommand
    Dim sql As String
    Private Sub BookCount()
        Dim DR As OleDb.OleDbDataReader
        Dim counter As Integer = 0
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "SELECT * FROM Books"
                cmd.Connection = connection()
                cmd.CommandText = sql
                DR = cmd.ExecuteReader
                While DR.Read
                    counter = counter + 1
                End While
                DR.Close()
                lblTotalBooks.Text = lblTotalBooks.Text & counter
            Else
                MsgBox("Could not connect with database!")
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            connection().Close()
        End Try
    End Sub
    Private Sub CustomerCount()
        Dim DR As OleDb.OleDbDataReader
        Dim counter As Integer = 0
        Try
            connection.Open()
            If connection().State = ConnectionState.Open Then
                sql = "SELECT * FROM Student"
                cmd.Connection = connection()
                cmd.CommandText = sql
                DR = cmd.ExecuteReader
                While DR.Read
                    counter = counter + 1
                End While
                DR.Close()
                lblTotalCustomer.Text = lblTotalCustomer.Text & counter
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            connection().Close()
        End Try
    End Sub
    Private Sub PublisherCount()
        Dim DR As OleDb.OleDbDataReader
        Dim counter As Integer = 0
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "SELECT * FROM Publisher"
                cmd.Connection = connection()
                cmd.CommandText = sql
                DR = cmd.ExecuteReader
                While DR.Read
                    counter = counter + 1
                End While
                DR.Close()
                lblTotalPublisher.Text = lblTotalPublisher.Text & counter
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub
    Private Sub OrderCount()
        Dim DR As OleDb.OleDbDataReader
        Dim counter As Integer = 0
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "SELECT * FROM Borrow"
                cmd.Connection = connection()
                cmd.CommandText = sql
                DR = cmd.ExecuteReader
                While DR.Read
                    counter = counter + 1
                End While
                DR.Close()
                lblTotalOrder.Text = lblTotalOrder.Text & counter
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            connection().Close()
        End Try
    End Sub
    Private Sub frmAdminDashBoard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BookCount()
        CustomerCount()
        OrderCount()
        PublisherCount()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Form1.Show()
        Me.Dispose()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        frmBooks.Show()
        Me.Dispose()
    End Sub

    Private Sub btnPublisher_Click(sender As Object, e As EventArgs) Handles btnPublisher.Click
        frmPublisher.Show()
        Me.Dispose()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        frmIssueBook.Show()
        Me.Dispose()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        frmStudent.Show()
        Me.Dispose()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        frmBorrowStatus.Show()
        Me.Dispose()
    End Sub
End Class