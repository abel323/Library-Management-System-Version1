﻿Public Class frmPublisher
    Dim cmd As New OleDb.OleDbCommand
    Dim sql As String
    'Dim pub_ID As Integer
    Private Sub frmPublisher_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'txtID.Hide()
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "SELECT * FROM Publisher"
                cmd.Connection = connection()
                cmd.CommandText = sql
                DA.SelectCommand = cmd
                DA.Fill(DT)
                dgvPublisher.DataSource = DT
            Else
                MsgBox("Could not connect with database!", vbCritical)
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmAdminDashBoard.Show()
        Me.Dispose()
    End Sub

    Private Sub dgvPublisher_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvPublisher.CellContentClick
        txtID.Text = dgvPublisher.Item(0, dgvPublisher.CurrentRow.Index).Value
        txtName.Text = dgvPublisher.Item(1, dgvPublisher.CurrentRow.Index).Value
        txtPhone.Text = dgvPublisher.Item(2, dgvPublisher.CurrentRow.Index).Value
        txtEmail.Text = dgvPublisher.Item(3, dgvPublisher.CurrentRow.Index).Value
        txtAddress.Text = dgvPublisher.Item(4, dgvPublisher.CurrentRow.Index).Value
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "INSERT INTO Publisher(Publisher_Name,Phone,Email,Address) VALUES('" & txtName.Text & "','" & txtPhone.Text &
                    "','" & txtEmail.Text & "','" & txtAddress.Text & "')"
                cmd.Connection = connection()
                cmd.CommandText = sql
                If cmd.ExecuteNonQuery > 0 Then
                    MsgBox("Publisher Added Successfully!", vbInformation)
                    sql = "SELECT * FROM Publisher"
                    cmd.CommandText = sql
                    DA.SelectCommand = cmd
                    DA.Fill(DT)
                    dgvPublisher.DataSource = DT
                Else
                    MsgBox("Could not add publisher", vbCritical)
                End If
            Else
                MsgBox("Could not connect with database!", vbCritical)
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "DELETE FROM Publisher WHERE Publisher_Name='" & txtName.Text & "'"
                cmd.Connection = connection()
                cmd.CommandText = sql
                If cmd.ExecuteNonQuery > 0 Then
                    MsgBox("Publisher Deleted Successfully!", vbInformation)
                    sql = "SELECT * FROM Publisher"
                    cmd.CommandText = sql
                    DA.SelectCommand = cmd
                    DA.Fill(DT)
                    dgvPublisher.DataSource = DT
                Else
                    MsgBox("Could not delete publisher!", vbCritical)
                End If
            Else
                MsgBox("Could not connect with database!")
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            connection().Open()
            sql = "UPDATE Publisher SET Publisher_Name='" & txtName.Text & "', Phone='" & txtPhone.Text &
                "', Email='" & txtEmail.Text & "', Address='" & txtAddress.Text & "' WHERE Publisher_ID=" & CInt(txtID.Text)
            cmd.Connection = connection()
            cmd.CommandText = sql
            If cmd.ExecuteNonQuery > 0 Then
                MsgBox("Publisher Data Updated Successfully!", vbInformation)
                sql = "SELECT * FROM Publisher"
                cmd.CommandText = sql
                DA.SelectCommand = cmd
                DA.Fill(DT)
                dgvPublisher.DataSource = DT
            Else
                MsgBox("Could not update database!")
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub
End Class