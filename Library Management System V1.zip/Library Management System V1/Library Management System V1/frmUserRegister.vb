﻿Public Class frmUserRegister
    Dim cmd As New OleDb.OleDbCommand
    Dim sql As String
    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        Form1.Show()
        Me.Dispose()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCance_Click(sender As Object, e As EventArgs) Handles btnCance.Click
        txtUserName.Clear()
        txtFirstName.Clear()
        txtLastName.Clear()
        txtMiddleName.Clear()
        txtPassword.Clear()
        txtDate.ResetText()
        cboUser.ResetText()
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        Dim Gender As String = ""
        If radMale.Checked Then
            Gender = "Male"
        ElseIf radFemale.Checked Then
            Gender = "Female"
        End If
        MsgBox(txtDate.Value.Date)
        Try
            AccessConnection.connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "INSERT INTO tblUser(User_Name,First_Name,Last_Name,Middle_Name,Gender,User_Type,Date_Of_Birth,UPassword) VALUES('" &
                    txtUserName.Text & "','" & txtFirstName.Text & "','" & txtLastName.Text & "','" & txtMiddleName.Text &
                    "','" & Gender & "','" & cboUser.Text & "','" & txtDate.Value.Date & "','" & txtPassword.Text & "')"
                cmd.Connection = AccessConnection.connection()
                cmd.CommandText = sql
                If cmd.ExecuteNonQuery > 0 Then
                    MsgBox("User Account Created Successfully!")
                Else
                    MsgBox("Could not register user account!", vbCritical)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message, vbCritical)
        Finally
            AccessConnection.connection().Close()
        End Try
    End Sub
End Class