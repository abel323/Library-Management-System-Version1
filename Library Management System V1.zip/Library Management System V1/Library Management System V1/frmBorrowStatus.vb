﻿Public Class frmBorrowStatus
    Dim cmd As New OleDb.OleDbCommand
    Dim sql As String
    Private Sub frmBorrowStatus_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtBorrowID.Visible = False
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "SELECT * FROM BorrowStatus"
                cmd.Connection = connection()
                cmd.CommandText = sql
                DA.SelectCommand = cmd
                DA.Fill(DT)
                DataGridView1.DataSource = DT
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Dim searchBy As String = cboSearchBy.Text
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                cmd.Connection = connection()
                Select Case searchBy
                    Case "ISBN"
                        sql = "SELECT * FROM BorrowStatus WHERE ISBN='" & txtSearch.Text & "'"
                        cmd.CommandText = sql
                        DA.SelectCommand = cmd
                        DA.Fill(DT)
                        DataGridView1.DataSource = DT
                    Case "Student ID"
                        sql = "SELECT * FROM BorrowStatus WHERE Student_ID=" & CInt(txtSearch.Text)
                        cmd.CommandText = sql
                        DA.SelectCommand = cmd
                        DA.Fill(DT)
                        DataGridView1.DataSource = DT
                    Case "Date Of Issued"
                        sql = "SELECT * FROM BorrowStatus WHERE Borrow_Date='" & txtSearch.Text & "'"
                        cmd.CommandText = sql
                        DA.SelectCommand = cmd
                        DA.Fill(DT)
                        DataGridView1.DataSource = DT
                    Case "Expected Return Date"
                        sql = "SELECT * FROM BorrowStatus WHERE Expected_Due_Date='" & txtSearch.Text & "'"
                        cmd.CommandText = sql
                        DA.SelectCommand = cmd
                        DA.Fill(DT)
                        DataGridView1.DataSource = DT
                End Select
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmAdminDashBoard.Show()
        Me.Dispose()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            connection().Open()
            If connection().State = ConnectionState.Open Then
                sql = "UPDATE Borrow SET Due_Date='" & txtDD.Text & "' WHERE BorrowID=" & txtBorrowID.Text
                cmd.Connection = connection()
                cmd.CommandText = sql
                If cmd.ExecuteNonQuery > 0 Then
                    MsgBox("Borrow Status Updated Successfully!", vbInformation)
                    txtBorrowID.Clear()
                    txtID.Clear()
                    txtFName.Clear()
                    txtLName.Clear()
                    txtISBN.Clear()
                    txtDOB.ResetText()
                    txtDD.ResetText()
                    txtEDD.ResetText()
                    txtSearch.Clear()
                    sql = "SELECT * FROM BorrowStatus"
                    cmd.CommandText = sql
                    DA.SelectCommand = cmd
                    DA.Fill(DT)
                    DataGridView1.DataSource = DT
                Else
                    MsgBox("Could not update borrow status!", vbCritical)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), vbCritical)
        Finally
            connection().Close()
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtBorrowID.Clear()
        txtID.Clear()
        txtFName.Clear()
        txtLName.Clear()
        txtISBN.Clear()
        txtDOB.ResetText()
        txtDD.ResetText()
        txtEDD.ResetText()
        txtSearch.Clear()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        txtBorrowID.Text = DataGridView1.Item(0, DataGridView1.CurrentRow.Index).Value
        txtISBN.Text = DataGridView1.Item(1, DataGridView1.CurrentRow.Index).Value
        txtID.Text = DataGridView1.Item(4, DataGridView1.CurrentRow.Index).Value
        txtFName.Text = DataGridView1.Item(5, DataGridView1.CurrentRow.Index).Value
        txtLName.Text = DataGridView1.Item(6, DataGridView1.CurrentRow.Index).Value
    End Sub
End Class